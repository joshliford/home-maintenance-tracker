package com.josh.home_maintenance_tracker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HomeMaintenanceTrackerApplication {

	public static void main(String[] args) {
		SpringApplication.run(HomeMaintenanceTrackerApplication.class, args);
	}

}
