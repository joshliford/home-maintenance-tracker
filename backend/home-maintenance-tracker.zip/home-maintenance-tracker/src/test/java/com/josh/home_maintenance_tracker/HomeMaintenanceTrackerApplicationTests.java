package com.josh.home_maintenance_tracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HomeMaintenanceTrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
